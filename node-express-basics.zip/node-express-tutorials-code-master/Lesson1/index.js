const {getName} = require('./student');

console.log(getName());
